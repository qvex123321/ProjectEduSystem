package MemberSystem.model;

import java.sql.Blob;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
@Entity
@Table(name = "AdminStaff")
@PrimaryKeyJoinColumn(name="memberId")
public class AdminStaffBean extends MembersBean{
	private static final long serialVersionUID = 1L;
	private int adminId;
	
	public AdminStaffBean() {
		super();
	}
	
	public AdminStaffBean(Integer memberId, String firstName, String lastName, String accountName, String password,
			String address, String email, String gender, String telePhone, String cellPhone, Date birthDate,
			Integer privilegeId, Timestamp registeredTime, Blob memberImage, String imageFileName,
			Timestamp modifiedTime, Integer activeStatus,int adminId) {
		super(memberId, firstName, lastName, accountName, password, address, email, gender, telePhone, cellPhone, birthDate,
				privilegeId, registeredTime, memberImage, imageFileName, modifiedTime, activeStatus);
		this.setAdminId(adminId);
	}
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int teacherId) {
		this.adminId = teacherId;
	}
}
