package MemberSystem.model;

import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Class")
public class ClassBean implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String classPeriodId;
	private Date startDate;
	private Date endDate;
	private String classroomId;
	private Set<ClassScheduleBean> classSchedules = new LinkedHashSet<>();
	private Set<StudentBean> students = new LinkedHashSet<>();
	private Set<CourseBean> courses = new LinkedHashSet<>();
	
	public ClassBean() { }

	public ClassBean(String classPeriodId, Date startDate, Date endDate, String classroomId) {
		super();
		this.classPeriodId = classPeriodId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.classroomId = classroomId;
	}
	
	public String getClassPeriodId() {
		return classPeriodId;
	}

	public void setClassPeriodId(String classPeriodId) {
		this.classPeriodId = classPeriodId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getClassroomId() {
		return classroomId;
	}

	public void setClassroomId(String classroomId) {
		this.classroomId = classroomId;
	}
	@OneToMany(mappedBy="class", cascade= {CascadeType.PERSIST}, orphanRemoval = false)
	public Set<StudentBean> getStudents() {
		return students;
	}

	public void setStudents(Set<StudentBean> student) {
		this.students = student;
	}

	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "students")
	public Set<CourseBean> getCourses() {
		return courses;
	}

	public void setCourses(Set<CourseBean> course) {
		this.courses = course;
	}

	@OneToMany(cascade=CascadeType.ALL, orphanRemoval = false)
	@JoinColumn(name="fk_classPeriodId", referencedColumnName="classPeriodId")
	public Set<ClassScheduleBean> getClassSchedules() {
		return classSchedules;
	}
	
	public void setClassSchedules(Set<ClassScheduleBean> classSchedule) {
		this.classSchedules = classSchedule;
	}
	
	
}
