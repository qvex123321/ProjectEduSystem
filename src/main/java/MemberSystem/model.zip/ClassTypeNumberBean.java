package MemberSystem.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "classTypeNumber")
public class ClassTypeNumberBean implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int classTypeId;
	private String classTypeName;
	private int PeriodNumber;
	
	public ClassTypeNumberBean() { }
	
	public ClassTypeNumberBean(int classTypeId, String classTypeName, int periodNumber) {
		super();
		this.classTypeId = classTypeId;
		this.classTypeName = classTypeName;
		PeriodNumber = periodNumber;
	}

	public int getClassTypeId() {
		return classTypeId;
	}

	public void setClassTypeId(int classTypeId) {
		this.classTypeId = classTypeId;
	}

	public String getClassTypeName() {
		return classTypeName;
	}

	public void setClassTypeName(String classTypeName) {
		this.classTypeName = classTypeName;
	}

	public int getPeriodNumber() {
		return PeriodNumber;
	}

	public void setPeriodNumber(int periodNumber) {
		PeriodNumber = periodNumber;
	}
	
}
