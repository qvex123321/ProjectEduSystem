package MemberSystem.model;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "classroom")
public class ClassroomBean implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	private String classroomId;
	private int capacity;
	private String roomType;
	private CourseBean course;
	private Set<RoomScheduleBean> roomSchedules = new LinkedHashSet<>();

	public ClassroomBean() { }
	
	public ClassroomBean(String classroomId, int capacity, String roomType) {
		super();
		this.classroomId = classroomId;
		this.capacity = capacity;
		this.roomType = roomType;
	}

	public String getClassroomId() {
		return classroomId;
	}

	public void setClassroomId(String classroomId) {
		this.classroomId = classroomId;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	
	@OneToOne(mappedBy="parkingSpace")
	public CourseBean getCourse() {
		return course;
	}

	public void setCourse(CourseBean course) {
		this.course = course;
	}
	
	@OneToMany(mappedBy="classroom", cascade= {CascadeType.PERSIST}, orphanRemoval = false)
	public Set<RoomScheduleBean> getRoomSchedules() {
		return roomSchedules;
	}

	public void setRoomSchedules(Set<RoomScheduleBean> roomSchedules) {
		this.roomSchedules = roomSchedules;
	}
	
}
