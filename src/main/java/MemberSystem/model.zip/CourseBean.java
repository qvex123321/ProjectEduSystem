package MemberSystem.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name = "Course")
public class CourseBean implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int courseId;
	private int classroomId;
	private int teacherId;
	private int courseListId;
	private String courseName;
	private String briefInfo;
	private int courseTime;
	private ClassBean aclass;
	private ClassroomBean classroom;
	
//	private Set<StudentBean> students = new HashSet<StudentBean>(0);
	
	public CourseBean() {}
	
	public CourseBean(int courseId, int classroomId, int teacherId, int courseListId, String courseName,
			String briefInfo, int courseTime) {
		super();
		this.courseId = courseId;
		this.classroomId = classroomId;
		this.teacherId = teacherId;
		this.courseListId = courseListId;
		this.courseName = courseName;
		this.briefInfo = briefInfo;
		this.courseTime = courseTime;
	}
	
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	
	public int getClassroomId() {
		return classroomId;
	}
	public void setClassroomId(int classroomId) {
		this.classroomId = classroomId;
	}
	public int getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(int teacherId) {
		this.teacherId = teacherId;
	}
	public int getCourseListId() {
		return courseListId;
	}
	public void setCourseListId(int courseListId) {
		this.courseListId = courseListId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getBriefInfo() {
		return briefInfo;
	}
	public void setBriefInfo(String briefInfo) {
		this.briefInfo = briefInfo;
	}
	public int getCourseTime() {
		return courseTime;
	}
	public void setCourseTime(int courseTime) {
		this.courseTime = courseTime;
	}
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name = "Class_course",  
		joinColumns = { 
			@JoinColumn(name = "courseId", nullable = false, updatable = false) 
		}, 
		inverseJoinColumns = { 
			@JoinColumn(name = "classPeriodId",	nullable = false, updatable = false) 
		}
	)
	public ClassBean getAclass() {
		return aclass;
	}

	public void setAclass(ClassBean aclass) {
		this.aclass = aclass;
	}
	
	@OneToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name="fk_classroomId") 
	public ClassroomBean getClassroom() {
		return classroom;
	}

	public void setClassroom(ClassroomBean classroom) {
		this.classroom = classroom;
	}
	
//	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//	@JoinTable(name = "Class_Course",  
//		joinColumns = { 
//			@JoinColumn(name = "courseId", nullable = false, updatable = false) 
//		}, 
//		inverseJoinColumns = { 
//			@JoinColumn(name = "classId", nullable = false, updatable = false) 
//		}
//	)
//	public Set<StudentBean> getStudents() {
//		return students;
//	}
//
//	public void setStudents(Set<StudentBean> students) {
//		this.students = students;
//	}
}
