package MemberSystem.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "RoomSchedule")
public class RoomScheduleBean implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int rSchedule;
	private int classId;
	private int year;
	private int month;
	private String dailySchedule;
	
	public RoomScheduleBean() { }
	
	public RoomScheduleBean(int pSchedule, int memberId, int year, int month, String dailySchedule) {
		super();
		this.rSchedule = pSchedule;
		this.classId = memberId;
		this.year = year;
		this.month = month;
		this.dailySchedule = dailySchedule;
	}

	public int getpSchedule() {
		return rSchedule;
	}

	public void setpSchedule(int pSchedule) {
		this.rSchedule = pSchedule;
	}

	public int getMemberId() {
		return classId;
	}

	public void setMemberId(int memberId) {
		this.classId = memberId;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public String getDailySchedule() {
		return dailySchedule;
	}

	public void setDailySchedule(String dailySchedule) {
		this.dailySchedule = dailySchedule;
	}
}
