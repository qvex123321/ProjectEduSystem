package MemberSystem.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Specialty")
public class SpecialtyBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private int specialtyId;
	private String specialtyName;
	
	private Set<TeacherBean> teachers = new HashSet<TeacherBean>(0);
	
	public SpecialtyBean() {}
	
	public SpecialtyBean(int specialtyId, String specialtyName) {
		super();
		this.specialtyId = specialtyId;
		this.specialtyName = specialtyName;
	}
	public int getSpecialtyId() {
		return specialtyId;
	}
	public void setSpecialtyId(int specialtyId) {
		this.specialtyId = specialtyId;
	}
	public String getSpecialtyName() {
		return specialtyName;
	}
	public void setSpecialtyName(String specialtyName) {
		this.specialtyName = specialtyName;
	}
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name = "Teacher_Specialty",  
		joinColumns = { 
			@JoinColumn(name = "specialtyId", nullable = false, updatable = false) 
		}, 
		inverseJoinColumns = { 
			@JoinColumn(name = "teacherId",	nullable = false, updatable = false) 
		}
	)
	public Set<TeacherBean> getTeachers() {
		return teachers;
	}

	public void setTeachers(Set<TeacherBean> teacheres) {
		this.teachers = teacheres;
	}
}
