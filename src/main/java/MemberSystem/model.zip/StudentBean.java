package MemberSystem.model;

import java.io.Serializable;
import java.sql.Blob;
import java.sql.Timestamp;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;


@Entity
@Table(name = "Student")
@PrimaryKeyJoinColumn(name="memberId")
public class StudentBean extends MembersBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer studentId;
//	private Integer memberId;
	private String classPeriodId;
	private Integer seatNo;
	private Set<CourseBean> courses = new LinkedHashSet<>();
	private ClassBean aclass = new ClassBean();

	public StudentBean() {
	}

	public StudentBean(Integer memberId, String firstName, String lastName, String accountName, String password,
			String address, String email, String gender, String telePhone, String cellPhone, Date birthDate,
			Integer privilegeId, Timestamp registeredTime, Blob memberImage, String imageFileName,
			Timestamp modifiedTime, Integer activeStatus, Integer studentId, String classPeriodId, Integer seatNo) {
		super();
		this.memberId = memberId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.accountName = accountName;
		this.password = password;
		this.address = address;
		this.email = email;
		this.gender = gender;
		this.telePhone = telePhone;
		this.cellPhone = cellPhone;
		this.birthDate = birthDate;
		this.privilegeId = privilegeId;
		this.registeredTime = registeredTime;
		this.memberImage = memberImage;
		this.imageFileName = imageFileName;
		this.modifiedTime = modifiedTime;
		this.activeStatus = activeStatus;
		setMemberId(memberId);
		setClassPeriodId(classPeriodId);
		setSeatNo(seatNo);
	}
	
	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getClassPeriodId() {
		return classPeriodId;
	}

	public void setClassPeriodId(String classPeriodId) {
		this.classPeriodId = classPeriodId;
	}

	public Integer getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(Integer seatNo) {
		this.seatNo = seatNo;
	}
	
	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "students")
	public Set<CourseBean> getCourses() {
		return courses;
	}

	public void setCourses(Set<CourseBean> courses) {
		this.courses = courses;
	}
	@ManyToOne 
	@JoinColumn(name="classPeriodId", nullable=false)  
	public ClassBean getAclass() {
		return aclass;
	}

	public void setAclass(ClassBean aclass) {
		this.aclass = aclass;
	}
}
