package MemberSystem.model;

import java.sql.Blob;
import java.sql.Timestamp;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "Teacher")
@PrimaryKeyJoinColumn(name="memberId")
public class TeacherBean extends MembersBean{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int teacherId;
	private Set<SpecialtyBean> specialties = new LinkedHashSet<>();
	private Set<TeacherScheduleBean> teacherSchedule = new LinkedHashSet<>();
	
	public TeacherBean() {
		super();
	}
	
	public TeacherBean(Integer memberId, String firstName, String lastName, String accountName, String password,
			String address, String email, String gender, String telePhone, String cellPhone, Date birthDate,
			Integer privilegeId, Timestamp registeredTime, Blob memberImage, String imageFileName,
			Timestamp modifiedTime, Integer activeStatus,int teacherId) {
		super(memberId, firstName, lastName, accountName, password, address, email, gender, telePhone, cellPhone, birthDate,
				privilegeId, registeredTime, memberImage, imageFileName, modifiedTime, activeStatus);
		this.setTeacherId(teacherId);
	}
	public int getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(int teacherId) {
		this.teacherId = teacherId;
	}
	
	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "teachers")
	public Set<SpecialtyBean> getSpecialties() {
		return specialties;
	}
	
	public void setSpecialties(Set<SpecialtyBean> specialties) {
		this.specialties = specialties;
	}
	
	@OneToMany(mappedBy="teacher", cascade= {CascadeType.PERSIST}, orphanRemoval = false)
	public Set<TeacherScheduleBean> getTeacherSchedule() {
		return teacherSchedule;
	}

	public void setTeacherSchedule(Set<TeacherScheduleBean> teacherSchedule) {
		this.teacherSchedule = teacherSchedule;
	}
}
