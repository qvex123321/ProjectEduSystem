package Schedule.Model;

import java.io.Serializable;

public class CourseBean extends CourseListBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private int courseId;
	private String classroomId;
	private int teacherId;
//	private int surveyId;
	private String classPeriodId;

	public CourseBean() {
		super();
	}

	public CourseBean(int courseListId, String courseName, int eduProgramTypeId, String briefInfo, int courseHour,
			int courseId, String classroomId, int teacherId, String classPeriodId) {
		super(courseListId, courseName, eduProgramTypeId, briefInfo, courseHour);
		this.courseId = courseId;
		this.classroomId = classroomId;
		this.teacherId = teacherId;
		this.classPeriodId = classPeriodId;
	}

//	public CourseBean(int courseId, int classroomId, int teacherId, String classPeriodId) {
//		super();
//		this.courseId = courseId;
//		this.classroomId = classroomId;
//		this.teacherId = teacherId;
//		this.classPeriodId = classPeriodId;
//	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public String getClassroomId() {
		return classroomId;
	}

	public void setClassroomId(String classroomId) {
		this.classroomId = classroomId;
	}

	public int getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(int teacherId) {
		this.teacherId = teacherId;
	}

	public String getClassPeriodId() {
		return classPeriodId;
	}

	public void setClassPeriodId(String classPeriodId) {
		this.classPeriodId = classPeriodId;
	}

}
